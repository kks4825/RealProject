package customer.controller;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@Component
public class CustomerController {
	@RequestMapping(value="/customerBoard.do", method=RequestMethod.GET)
	public ModelAndView mypage(){
		ModelAndView mav = new ModelAndView();
		mav.addObject("display", "/board/boardMain.jsp");
		mav.setViewName("/index/index");
		
		return mav;
	}
}
