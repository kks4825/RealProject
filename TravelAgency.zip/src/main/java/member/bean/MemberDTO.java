package member.bean;

public class MemberDTO {
	private String memSeq;
	private String memId;
	private String memPwd;
	private String memPwdChk;
	private String memName;
	private String memBirth01;
	private String memBirth02;
	private String memBirth03;
	private String memGender;
	private String memEmail;
	private String memEmail0;
	private String memZipCode;
	private String memAddr1;
	private String memAddr2;
	private String memMobile01;
	private String memMobile02;
	private String memMobile03;
	private String contry;
	private String lastName;
	private String firstName;
	private String passportNumber;
	private String passportStartYear;
	private String passportStartMonth;
	private String passportStartDay;
	private String passportEndYear;
	private String passportEndMonth;
	private String passportEndDay;
	private String visaContry;
	private String visaStartYear;
	private String visaStartMonth;
	private String visaStartDay;
	private String visaEndYear;
	private String visaEndMonth;
	private String visaEndDay;
	
	public String getMemSeq() {
		return memSeq;
	}
	public void setMemSeq(String memSeq) {
		this.memSeq = memSeq;
	}
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getMemPwd() {
		return memPwd;
	}
	public void setMemPwd(String memPwd) {
		this.memPwd = memPwd;
	}
	public String getMemPwdChk() {
		return memPwdChk;
	}
	public void setMemPwdChk(String memPwdChk) {
		this.memPwdChk = memPwdChk;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public String getMemBirth01() {
		return memBirth01;
	}
	public void setMemBirth01(String memBirth01) {
		this.memBirth01 = memBirth01;
	}
	public String getMemBirth02() {
		return memBirth02;
	}
	public void setMemBirth02(String memBirth02) {
		this.memBirth02 = memBirth02;
	}
	public String getMemBirth03() {
		return memBirth03;
	}
	public void setMemBirth03(String memBirth03) {
		this.memBirth03 = memBirth03;
	}
	public String getMemGender() {
		return memGender;
	}
	public void setMemGender(String memGender) {
		this.memGender = memGender;
	}
	public String getMemEmail() {
		return memEmail;
	}
	public void setMemEmail(String memEmail) {
		this.memEmail = memEmail;
	}
	public String getMemEmail0() {
		return memEmail0;
	}
	public void setMemEmail0(String memEmail0) {
		this.memEmail0 = memEmail0;
	}
	public String getMemZipCode() {
		return memZipCode;
	}
	public void setMemZipCode(String memZipCode) {
		this.memZipCode = memZipCode;
	}
	public String getMemAddr1() {
		return memAddr1;
	}
	public void setMemAddr1(String memAddr1) {
		this.memAddr1 = memAddr1;
	}
	public String getMemAddr2() {
		return memAddr2;
	}
	public void setMemAddr2(String memAddr2) {
		this.memAddr2 = memAddr2;
	}
	public String getMemMobile01() {
		return memMobile01;
	}
	public void setMemMobile01(String memMobile01) {
		this.memMobile01 = memMobile01;
	}
	public String getMemMobile02() {
		return memMobile02;
	}
	public void setMemMobile02(String memMobile02) {
		this.memMobile02 = memMobile02;
	}
	public String getMemMobile03() {
		return memMobile03;
	}
	public void setMemMobile03(String memMobile03) {
		this.memMobile03 = memMobile03;
	}
	public String getContry() {
		return contry;
	}
	public void setContry(String contry) {
		this.contry = contry;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}
	public String getPassportStartYear() {
		return passportStartYear;
	}
	public void setPassportStartYear(String passportStartYear) {
		this.passportStartYear = passportStartYear;
	}
	public String getPassportStartMonth() {
		return passportStartMonth;
	}
	public void setPassportStartMonth(String passportStartMonth) {
		this.passportStartMonth = passportStartMonth;
	}
	public String getPassportStartDay() {
		return passportStartDay;
	}
	public void setPassportStartDay(String passportStartDay) {
		this.passportStartDay = passportStartDay;
	}
	public String getPassportEndYear() {
		return passportEndYear;
	}
	public void setPassportEndYear(String passportEndYear) {
		this.passportEndYear = passportEndYear;
	}
	public String getPassportEndMonth() {
		return passportEndMonth;
	}
	public void setPassportEndMonth(String passportEndMonth) {
		this.passportEndMonth = passportEndMonth;
	}
	public String getPassportEndDay() {
		return passportEndDay;
	}
	public void setPassportEndDay(String passportEndDay) {
		this.passportEndDay = passportEndDay;
	}
	public String getVisaContry() {
		return visaContry;
	}
	public void setVisaContry(String visaContry) {
		this.visaContry = visaContry;
	}
	public String getVisaStartYear() {
		return visaStartYear;
	}
	public void setVisaStartYear(String visaStartYear) {
		this.visaStartYear = visaStartYear;
	}
	public String getVisaStartMonth() {
		return visaStartMonth;
	}
	public void setVisaStartMonth(String visaStartMonth) {
		this.visaStartMonth = visaStartMonth;
	}
	public String getVisaStartDay() {
		return visaStartDay;
	}
	public void setVisaStartDay(String visaStartDay) {
		this.visaStartDay = visaStartDay;
	}
	public String getVisaEndYear() {
		return visaEndYear;
	}
	public void setVisaEndYear(String visaEndYear) {
		this.visaEndYear = visaEndYear;
	}
	public String getVisaEndMonth() {
		return visaEndMonth;
	}
	public void setVisaEndMonth(String visaEndMonth) {
		this.visaEndMonth = visaEndMonth;
	}
	public String getVisaEndDay() {
		return visaEndDay;
	}
	public void setVisaEndDay(String visaEndDay) {
		this.visaEndDay = visaEndDay;
	}
	
	
}
