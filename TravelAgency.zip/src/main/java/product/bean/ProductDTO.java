package product.bean;


public class ProductDTO {
	private int pack_no;
	private String pack_title;
	private int pack_price_kid;
	private int pack_price_adult;
	private String pack_desc;
	private String pack_city;
	private String pack_depart;
	private String pack_arriv;
	private String pack_air;
	private String pack_detail;
	private String tour_info;
	private String tour_ref;
	private String image1;
	private String image2;
	private String image3;
	private String image4;
	private String image5;
	private String image6;
	private String image7;
	private String image8;
	private String image9;
	
	public int getPack_no() {
		return pack_no;
	}
	public void setPack_no(int pack_no) {
		this.pack_no = pack_no;
	}
	public String getPack_title() {
		return pack_title;
	}
	public void setPack_title(String pack_title) {
		this.pack_title = pack_title;
	}
	public int getPack_price_kid() {
		return pack_price_kid;
	}
	public void setPack_price_kid(int pack_price_kid) {
		this.pack_price_kid = pack_price_kid;
	}
	public int getPack_price_adult() {
		return pack_price_adult;
	}
	public void setPack_price_adult(int pack_price_adult) {
		this.pack_price_adult = pack_price_adult;
	}
	public String getPack_desc() {
		return pack_desc;
	}
	public void setPack_desc(String pack_desc) {
		this.pack_desc = pack_desc;
	}
	public String getPack_city() {
		return pack_city;
	}
	public void setPack_city(String pack_city) {
		this.pack_city = pack_city;
	}
	/*public Date getPack_depart() {
		return pack_depart;
	}
	public void setPack_depart(Date pack_depart) {
		this.pack_depart = pack_depart;
	}
	public Date getPack_arriv() {
		return pack_arriv;
	}
	public void setPack_arriv(Date pack_arriv) {
		this.pack_arriv = pack_arriv;
	}*/
	
	public String getPack_air() {
		return pack_air;
	}
	public String getPack_depart() {
		return pack_depart;
	}
	public void setPack_depart(String pack_depart) {
		this.pack_depart = pack_depart;
	}
	public String getPack_arriv() {
		return pack_arriv;
	}
	public void setPack_arriv(String pack_arriv) {
		this.pack_arriv = pack_arriv;
	}
	public void setPack_air(String pack_air) {
		this.pack_air = pack_air;
	}
	public String getPack_detail() {
		return pack_detail;
	}
	public void setPack_detail(String pack_detail) {
		this.pack_detail = pack_detail;
	}
	public String getTour_info() {
		return tour_info;
	}
	public void setTour_info(String tour_info) {
		this.tour_info = tour_info;
	}
	public String getTour_ref() {
		return tour_ref;
	}
	public void setTour_ref(String tour_ref) {
		this.tour_ref = tour_ref;
	}
	public String getImage1() {
		return image1;
	}
	public void setImage1(String image1) {
		this.image1 = image1;
	}
	public String getImage2() {
		return image2;
	}
	public void setImage2(String image2) {
		this.image2 = image2;
	}
	public String getImage3() {
		return image3;
	}
	public void setImage3(String image3) {
		this.image3 = image3;
	}
	public String getImage4() {
		return image4;
	}
	public void setImage4(String image4) {
		this.image4 = image4;
	}
	public String getImage5() {
		return image5;
	}
	public void setImage5(String image5) {
		this.image5 = image5;
	}
	public String getImage6() {
		return image6;
	}
	public void setImage6(String image6) {
		this.image6 = image6;
	}
	public String getImage7() {
		return image7;
	}
	public void setImage7(String image7) {
		this.image7 = image7;
	}
	public String getImage8() {
		return image8;
	}
	public void setImage8(String image8) {
		this.image8 = image8;
	}
	public String getImage9() {
		return image9;
	}
	public void setImage9(String image9) {
		this.image9 = image9;
	}
	
}
