package product.bean;

public class BankDTO {
	private int bank_no;
	private String bank_name;
	private double bank_account;
	
	public int getBank_no() {
		return bank_no;
	}
	public void setBank_no(int bank_no) {
		this.bank_no = bank_no;
	}
	public String getBank_name() {
		return bank_name;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public double getBank_account() {
		return bank_account;
	}
	public void setBank_account(double bank_account) {
		this.bank_account = bank_account;
	}
	
	
}
